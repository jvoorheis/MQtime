SUBJECT:    mqtime: A Stata Tool for Calculating Travel Time and Distance Using Mapquest Web Services

AUTHOR(S):  John Voorheis
            University of Oregon


SUPPORT:    jlv@uoregon.edu

HELP:       After installation, type


            . help mqtime
            . help mqgeocode

FILES:


mqgeocode.ado
mqgeocode.hlp
mqtime.ado
mqtime.hlp
mqtime_example.do
statecap.csv
